package com.teamdui.profiler.ui.history;

public class rec {
    public int cal;
    public double calburn;
    public String date;

    rec(int c, double cal, String d) {
        this.cal = c;
        this.calburn = cal;
        this.date = d;
    }
}
