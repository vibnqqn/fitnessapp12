package com.teamdui.profiler.ui.history;

public class progress {
    public int cal;
    public int wat;
    public int exr;
    public double calburn;

    public progress() {
        cal = 0;
        wat = 0;
        exr = 0;
        calburn = 0;
    }
}
