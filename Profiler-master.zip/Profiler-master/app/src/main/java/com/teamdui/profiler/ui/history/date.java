package com.teamdui.profiler.ui.history;

public class date {
    public set set;
    public progress progress;

    public date() {
        set = new set();
        progress = new progress();
    }
}
