package com.teamdui.profiler.ui.history;

public class set {
    public int cal;
    public int wat;
    public int exr;

    public set() {
        cal = 0;
        wat = 0;
        exr = 0;
    }
}
