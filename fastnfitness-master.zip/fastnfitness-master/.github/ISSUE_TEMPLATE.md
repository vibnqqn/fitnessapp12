Found in version:

Current behavior:

Expected behavior:

Step to reproduce:


