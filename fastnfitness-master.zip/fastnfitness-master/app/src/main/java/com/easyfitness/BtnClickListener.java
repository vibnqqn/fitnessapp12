package com.easyfitness;

import android.view.View;

/**
 * Created by ccombes on 17/09/20.
 */

public interface BtnClickListener {
    void onBtnClick(View v);
}
